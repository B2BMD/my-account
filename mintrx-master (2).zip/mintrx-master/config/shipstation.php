<?php

return [
    'apiURL'        => env('SS_URL', 'https://ssapi.shipstation.com'),
    'apiKey'        => env('SHIP_STATION_API_KEY', ''),
    'partnerApiKey' => env('SS_PARTNER_KEY', ''),
    'apiSecret'     => env('SHIP_STATION_API_SECRET', ''),
];

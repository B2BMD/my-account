<?php

namespace App\Exceptions;

use Exception;
use Throwable;

class StripeSomeThingWentWrong extends Exception implements Throwable
{
    //
}

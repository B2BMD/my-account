<?php

namespace  App\Exceptions;

use Exception;
use Throwable;

class SomeThingWentWrong extends Exception implements Throwable
{
    //
}

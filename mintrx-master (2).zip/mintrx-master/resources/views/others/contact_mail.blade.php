<span >Hey!! , {{$data['email']}} has sent you a message.</span>
<br>
<span>{{ $data['message'] }}</span><br><br>
<span>Thankyou </span>
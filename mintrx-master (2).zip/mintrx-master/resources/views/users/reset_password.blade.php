<span style="text-align:center">Welcome to Medical Weight Loss Centers of America. Please click on the below link to reset your password</span>
<br>
<a href="{{ $data['link'] }}" style="text-align:center">{{ $data['link'] }}</a><br><br>
<span>Thankyou </span>

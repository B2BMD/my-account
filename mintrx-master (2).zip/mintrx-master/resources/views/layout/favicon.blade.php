<head>
<link rel="shortcut icon"  type="image/x-icon" href="{{env('FAV_ICON')}}">
</head>
<style type="text/css">
    :root {
    --Primarycolor:  <?php echo env('PRIMARYCOLOR')?>;
    --Secondarycolor: <?php echo env('SECONDARYCOLOR')?>;
    }
</style>
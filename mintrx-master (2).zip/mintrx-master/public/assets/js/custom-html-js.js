function Displaysocial_icons() {
    var element = document.getElementById("foorerSocialMedia");
    element.classList.toggle("hide");
}
function displayhaederhtml() {
    var element = document.getElementById("headerhtml");
    element.classList.toggle("hide");
}
function displayDownloadAppbadges() {
    var element = document.getElementById("foorerappbadges");
    element.classList.toggle("hide");
}
function DisplayPaymentTrustbadges() {
    var element = document.getElementById("foorerPaymentbadgs");
    element.classList.toggle("hide");
}
